<?php

namespace App\Livewire;

use Livewire\Component;
use App\Http\Models\User;
use Validated;

class LoginRegistration extends Component
{
    public $user, $email, $password, $name;
    public $registerForm = false;
    public function render()
    {
        return view('livewire.login-registration');
    }

    public function login()
    {
        $validatedData = $this->validate([
            'email' => 'required email',
            'password' => 'required',
        ]);
        if (\Auth::attempt(['email' => $this->email, 'password' => $this->password])) {
            session()->flash('message', 'You are login successfully.');
        }else{
            session()->flash('error','email and password are wrong.');
        }
    }

    public function register(){
        $this->registerForm = !$this->registerForm;
    }

    public function registerStore()
    {
        $validatedData = $this->validate([
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            // 'password_confirmation' => 'required|confirmed',
            ]);
        $this->password = Hash::make($this->password);
        User::create(['name' => $this->name,'email' => $this->email, 'password' => $this->password]);
        // session()->flash('message', 'Your register successfully, Go to the login page');
        $this->registerForm = $this->registerForm;
    }
}
