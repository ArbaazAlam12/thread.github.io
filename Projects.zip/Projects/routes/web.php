<?php

use Illuminate\Support\Facades\Route;
use App\Http\Livewire\Login;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::view('/login', 'livewire.login-register');
// Route::view('/register', 'livewire.register');
// Route::get('/register', \App\Http\Livewire\register::class);
