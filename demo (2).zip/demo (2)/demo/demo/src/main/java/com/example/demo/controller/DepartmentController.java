package com.example.demo.controller;

import com.example.demo.dto.DepartmentDTO;
import com.example.demo.entities.DepartmentEntity;
import com.example.demo.services.DepartmentService;
import org.aspectj.bridge.IMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/department")
public class DepartmentController {

    private DepartmentService departmentService;

    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @GetMapping("/findAll")
    public ResponseEntity findAllDepartment() {

        return new ResponseEntity(departmentService.findAll(), HttpStatus.OK);
    }

    @PostMapping("/save")
    public ResponseEntity save(@RequestBody DepartmentEntity departmentEntity) {
        DepartmentEntity savedDepartment = departmentService.save(departmentEntity);
        return new ResponseEntity(savedDepartment, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity delete(@PathVariable Long id) {
        try {
            departmentService.delete(id);
            return new ResponseEntity("Deleted successfully", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity("Error deleting the department, Enter Correct ID", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/findById/{id}")
    public ResponseEntity findById(@PathVariable Long id) {
        try {
            return new ResponseEntity(departmentService.findById(id), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity("Error finding the Id, Enter Correct ID", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/update")
    public ResponseEntity update(@RequestBody DepartmentEntity departmentEntity) {
        try {
                return new ResponseEntity(departmentService.update(departmentEntity), HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity("Error Updating the department, Enter Correct ID", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
