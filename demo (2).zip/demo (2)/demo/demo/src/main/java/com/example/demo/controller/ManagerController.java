package com.example.demo.controller;

import com.example.demo.entities.DepartmentEntity;
import com.example.demo.entities.ManagerEntity;
import com.example.demo.services.DepartmentService;
import com.example.demo.services.ManagerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/manager")
public class ManagerController {

    private ManagerService managerService;

    public ManagerController(ManagerService managerService) {
        this.managerService = managerService;
    }
    @GetMapping("/findAll")
    public ResponseEntity findAllManager(){
        return new ResponseEntity(managerService.FindAll(), HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteManager(@PathVariable Long id){
        return new ResponseEntity(deleteManager(id), HttpStatus.OK);
    }

    @PostMapping("/save")
    public ResponseEntity saveManager(@RequestBody ManagerEntity managerEntity){
        return new ResponseEntity(managerService.save(managerEntity), HttpStatus.OK);
    }

//    @GetMapping("/findById")
//    public ResponseEntity findByIdManager(@PathVariable Long id){
//        return new ResponseEntity(managerService.FindById(id), HttpStatus.OK);
//    }
}
