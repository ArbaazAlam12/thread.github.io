package com.example.demo.services;

import com.example.demo.dto.ManagerDTO;
import com.example.demo.entities.ManagerEntity;
import com.example.demo.repository.ManagerRepository;
import com.example.demo.utility.CustomerMapperManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.ArrayList;
import java.util.List;

@Service
public class ManagerService {
    @Autowired
    private ManagerRepository managerRepository;

    public ManagerService(ManagerRepository managerRepository){
        this.managerRepository=managerRepository;
    }

    public ManagerEntity save(ManagerEntity managerEntity){
        return managerRepository.save(managerEntity);
    }

    public void delete(Long id){
         managerRepository.deleteById(id);
    }

    public ManagerEntity update(ManagerEntity managerEntity){
        return managerRepository.save(managerEntity);
    }

    public List<ManagerEntity> FindAll(){
        return managerRepository.findAll();
    }

    public ManagerDTO findById(Long id){
        ManagerDTO managerDTO = CustomerMapperManager.convertToManagerDTO(managerRepository.findById(id).get());
        return managerDTO;
    }
    public List<ManagerEntity> getManagerByDepartmentId(@PathVariable Long departmentId) {
        ManagerEntity manager = managerRepository.findByDepartment_Id(departmentId);
        List<ManagerEntity> managerList = new ArrayList<>();
        if (manager != null) {
            managerList.add(manager);
        }
        return managerList;
    }
}
