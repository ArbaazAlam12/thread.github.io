package com.example.demo.services;

import com.example.demo.dto.EmployeeDTO;
import com.example.demo.entities.DepartmentEntity;
import com.example.demo.entities.EmployeeEntity;
import com.example.demo.entities.ManagerEntity;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.utility.CustomerMapperEmployee;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;
    private EntityManager entityManager;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public EmployeeEntity save(EmployeeEntity employeeEntity){
        return employeeRepository.save(employeeEntity);
    }

    public void delete(Long id){
        employeeRepository.deleteById(id);
    }

    public List<EmployeeEntity> findAll(){
        return employeeRepository.findAll();
    }

    public EmployeeDTO findById(Long id){
        EmployeeDTO employeeDTO= CustomerMapperEmployee.convertToManagerDto(employeeRepository.findById(id).get());
        return employeeDTO;
   }

   public EmployeeEntity update(EmployeeEntity employeeEntity){
        return employeeRepository.save(employeeEntity);
   }

    public List<EmployeeEntity> getEmployeeByManagerId(@PathVariable Long managerId) {
        EmployeeEntity employee = employeeRepository.findByEmployee_Id(managerId);
        List<EmployeeEntity> employeeList = new ArrayList<>();
        if (employee != null) {
            employeeList.add(employee);
        }
        return employeeList;
    }

    public void assignNewManagerToEmployees(List<Long> employeeIds, Long newManagerId) {
        ManagerEntity newManager = entityManager.find(ManagerEntity.class, newManagerId);
        entityManager.createQuery(
                        "UPDATE EmployeeEntity e " +
                                "SET e.manager_id = :newManager " +
                                "WHERE e.id IN :employeeIds")
                .setParameter("newManager", newManager)
                .setParameter("employeeIds", employeeIds)
                .executeUpdate();
    }
}
