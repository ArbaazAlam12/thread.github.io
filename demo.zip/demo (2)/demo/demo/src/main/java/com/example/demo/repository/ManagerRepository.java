package com.example.demo.repository;

import com.example.demo.entities.ManagerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ManagerRepository extends JpaRepository<ManagerEntity, Long> {
    @Query(value = "SELECT * FROM manager m WHERE m.department_id = :departmentId", nativeQuery = true)
    ManagerEntity findByDepartment_Id(@Param("departmentId") Long departmentId);
}
