package com.example.demo.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "employee")
public class EmployeeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "employee_name")
    private String name;

    @Column(name = "email")
    private String email;

    @Column(name = "contact")
    private String contact;

    @Column(name = "address")
    private String address;

    @ManyToOne
    @Column(name = "department_id")
    private DepartmentEntity department_id;

    @ManyToOne
    @Column(name = "manager_id")
    private ManagerEntity manager_id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public DepartmentEntity getDepartment_id() {
        return department_id;
    }

    public void setDepartment_id(DepartmentEntity department_id) {
        this.department_id = department_id;
    }

    public ManagerEntity getManager_id() {
        return manager_id;
    }

    public void setManager_id(ManagerEntity manager_id) {
        this.manager_id = manager_id;
    }
}
